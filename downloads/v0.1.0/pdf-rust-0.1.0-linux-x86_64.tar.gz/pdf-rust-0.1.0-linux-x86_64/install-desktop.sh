#!/bin/sh
# Registers pdf-rust for the current user: desktop entry, icon and MIME type.
# Run it from this directory; uninstall with `--uninstall`.
set -e
here=$(cd "$(dirname "$0")" && pwd)
apps="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
icons="${XDG_DATA_HOME:-$HOME/.local/share}/icons/hicolor/256x256/apps"
mime="${XDG_DATA_HOME:-$HOME/.local/share}/mime/packages"

if [ "$1" = "--uninstall" ]; then
  rm -f "$apps/pdf-rust.desktop" "$icons/pdf-rust.png" "$mime/pdf-rust.xml"
  command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$apps" || true
  command -v update-mime-database >/dev/null 2>&1 && update-mime-database "${XDG_DATA_HOME:-$HOME/.local/share}/mime" || true
  echo "pdf-rust desktop integration removed"
  exit 0
fi

mkdir -p "$apps" "$icons" "$mime"
cat > "$apps/pdf-rust.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=pdf-rust
GenericName=PDF Viewer
Comment=Fast, native PDF reader
Exec=$here/pdf-rust %F
Icon=pdf-rust
Terminal=false
Categories=Office;Viewer;Graphics;
MimeType=application/pdf;
StartupWMClass=pdf-rust
DESKTOP
if [ -f "$here/pdf-rust.png" ]; then cp "$here/pdf-rust.png" "$icons/pdf-rust.png"; fi
cat > "$mime/pdf-rust.xml" <<'XML'
<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
  <mime-type type="application/pdf"><icon name="pdf-rust"/></mime-type>
</mime-info>
XML
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$apps" || true
command -v update-mime-database >/dev/null 2>&1 && update-mime-database "${XDG_DATA_HOME:-$HOME/.local/share}/mime" || true
echo "pdf-rust registered in $apps (remove with ./install-desktop.sh --uninstall)"
